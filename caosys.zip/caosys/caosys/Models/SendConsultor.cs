﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace caosys.Models
{
    public class SendConsultor
    {

      public string Mesini { get; set; }
      public long Anhoini { get; set; }
      public string Mesend { get; set; }
      public long Anhoend { get; set; }
      public string Consultores { get; set; }

    }
}