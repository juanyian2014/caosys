﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Mvc;
using caosys.Models;
using System.Data;
using System.Data.SqlClient;

namespace caosys.Controllers
{
    public class ComercialController : Controller
    {
        // GET: Comercial
        public ActionResult Index()
        {
            DsCaol ds = new DsCaol();
            Models.DsCaolTableAdapters.DaUsuarioPermisaoSistema da = new Models.DsCaolTableAdapters.DaUsuarioPermisaoSistema();
            Models.DsCaolTableAdapters.DaMinMaxDataEmissao daMinMaxDate = new Models.DsCaolTableAdapters.DaMinMaxDataEmissao();
            da.Fill(ds.DtUsuariPermisaoSistema);
            daMinMaxDate.Fill(ds.DtMinDataEmissao);

            ViewBag.ListConsultores = ds.DtUsuariPermisaoSistema.AsEnumerable().ToList();
            ViewBag.ListMinMaxYearFactura = ds.DtMinDataEmissao.AsEnumerable().ToList();

            String[] month = { "Jan", "Fev", "Mar", "Abr", "Mai", "Jun", "Jul", "Ago", "Set", "Out", "Nov", "Dez" };
            List<SendMonth> dmonth = new List<SendMonth>();
            for (Int32 i = 1; i <= 12; i++)
                dmonth.Add(new SendMonth { Month = i, Name = month[i - 1] });

            ViewBag.ListMonth = dmonth.AsEnumerable().ToList();


            return View();
        }

        public ActionResult PorConsultor()
        {
            return View();
        }

       

       public ActionResult RelatorioR(FormCollection items)
        {
           
            return PartialView(GetDataReceitasLiquidas(items));
        }

        public JsonResult PizzaRelatorio(FormCollection items)
        {

            try
            {
                string consultores = items["Consultores"];
                int mesini = Convert.ToInt32(items["Mesini"]);
                int mesend = Convert.ToInt32(items["Mesend"]);
                int anhoini = Convert.ToInt32(items["Anhoini"]);
                int anhoend = Convert.ToInt32(items["Anhoend"]);

                DsCaol ds = new DsCaol();
                Models.DsCaolTableAdapters.DaReceitasliquidasbconsultor da = new Models.DsCaolTableAdapters.DaReceitasliquidasbconsultor();
                da.Fill(ds.DtReceitasliquidasbyconsultor, consultores, mesini, anhoini, mesend, anhoend);


                var dtdata = ds.DtReceitasliquidasbyconsultor.AsEnumerable().Select(x => new { x.co_usuario, x.no_usuario,x.receitaliquida }).ToList();
  

                var jsonResult = Json(new { success = true, data = dtdata, message = "Data OK" }, JsonRequestBehavior.AllowGet);
                jsonResult.MaxJsonLength = Int32.MaxValue;
                return jsonResult;

            }
            catch (Exception ex)
            {
                return Json(new { success = false,  message = ex.Message }, JsonRequestBehavior.AllowGet);

            }

           
        }


        public JsonResult GraficoRelatorio(FormCollection items)
        {

            try
            {
              
                var dtdata = GetDataReceitasLiquidas(items).AsEnumerable().Select(x => new { x.co_usuario, x.no_usuario, x.receitaliquida,x.costofixo, x.mes }).ToList();

                var jsonResult = Json(new { success = true, data = dtdata, message = "Data OK" }, JsonRequestBehavior.AllowGet);
                jsonResult.MaxJsonLength = Int32.MaxValue;
                return jsonResult;

            }
            catch (Exception ex)
            {
                return Json(new { success = false, message = ex.Message }, JsonRequestBehavior.AllowGet);

            }


        }


        private DsCaol.DtReceitasliquidasDataTable GetDataReceitasLiquidas(FormCollection items)
        {
            string consultores = items["Consultores"];
            int mesini = Convert.ToInt32(items["Mesini"]);
            int mesend = Convert.ToInt32(items["Mesend"]);
            int anhoini = Convert.ToInt32(items["Anhoini"]);
            int anhoend = Convert.ToInt32(items["Anhoend"]);

            DsCaol ds = new DsCaol();
            Models.DsCaolTableAdapters.DaReceitasLiquidas da = new Models.DsCaolTableAdapters.DaReceitasLiquidas();
            da.Fill(ds.DtReceitasliquidas, consultores, mesini, anhoini, mesend, anhoend);

            return ds.DtReceitasliquidas;
        }

       

    }

   
}